package prog6112eaq1;

/**
 *
 * @author lindelo Desiree Nkosi
 */
public class PROG6112EaQ1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
